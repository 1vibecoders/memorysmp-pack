#version 330

// MemorySMP override of the vanilla 1.21.11 rendertype_item_entity_translucent_cull.fsh.
// Only change: the storm wall (texture blue channel exactly 254) skips distance fog, so the far wall of a
// big Royale zone does not fade into the sky. Everything else renders exactly like vanilla.

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;
in vec2 texCoord1;

out vec4 fragColor;

void main() {
    vec4 tex = texture(Sampler0, texCoord0);
    vec4 color = tex * vertexColor * ColorModulator;
    if (color.a < 0.1) {
        discard;
    }
    if (abs(tex.b * 255.0 - 254.0) < 0.5) {
        fragColor = color; // storm wall: no fog
        return;
    }
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
